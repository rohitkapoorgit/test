package org.rohit;

import java.util.Set;
import java.util.TreeSet;

public class NetHack {

	public String[] explode(String bombs, int force){

		
		int size = bombs.length();
		
		if(size < 1 || size > 50)
			System.out.println("The length of 'bombs' must be 1 to 50 characters long");
		
		if(force < 1 || force > 10)
			System.out.println("Only a force between 1 and 10 inclusive is permitted");

	}
	
	public Set<String> initializeShrapnel(String bombs){
		
		 Set<Character> left = new TreeSet<Character>();
		 Set<Character> right = new TreeSet<Character>();
		
		 for(int c=0; c<=bombs.length()-1;c++){
			 
			 if(bombs[c] == 'B'){
				 
		       
			 }
		 }
		
		
	}
	
}